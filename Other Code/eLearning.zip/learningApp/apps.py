from django.apps import AppConfig


class LearningappConfig(AppConfig):
    name = 'learningApp'
